/*
1. In this case, we wish to know if a tree T is the minimal spanning tree of a graph G. We
aim to demonstrate that T is a minimal spanning tree of G if and only if T has an edge e
that is one of the least cost edges in the cut (S, S’).
A. Demonstrate that if a cut (S, S’) exists such that T contains no of its minimal cost
edges, T cannot be a minimum spanning tree. (10 points)
*/

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Edge {
    int u, v, weight;
    Edge(int u, int v, int weight) : u(u), v(v), weight(weight) {}
};

bool compareEdges(Edge a, Edge b) {
    return a.weight < b.weight;
}

int findParent(int node, vector<int>& parent) {
    if (parent[node] == -1)
        return node;
    return findParent(parent[node], parent);
}

bool isCycle(int u, int v, vector<int>& parent) {
    int parentU = findParent(u, parent);
    int parentV = findParent(v, parent);
    if (parentU == parentV)
        return true;
    parent[parentU] = parentV;
    return false;
}

bool hasMinimalEdges(vector<Edge>& edges, vector<Edge>& minimalEdges) {
    vector<int> parent(edges.size(), -1);
    for (Edge edge : edges) {
        if (!isCycle(edge.u, edge.v, parent)) {
            minimalEdges.push_back(edge);
        }
    }
    return minimalEdges.size() == edges.size() - 1;
}

int main() {
    int n, m; // n = number of nodes, m = number of edges
    cin >> n >> m;

    vector<Edge> edges;
    for (int i = 0; i < m; ++i) {
        int u, v, weight;
        cin >> u >> v >> weight;
        edges.push_back(Edge(u, v, weight));
    }

    sort(edges.begin(), edges.end(), compareEdges);

    vector<Edge> minimalEdges;
    if (hasMinimalEdges(edges, minimalEdges)) {
        cout << "The given tree has all minimal cost edges in some cut." << endl;
    } else {
        cout << "The given tree does not have all minimal cost edges in any cut." << endl;
    }

    return 0;
}

/*
Input:

5 7
1 2 5
1 3 10
2 3 15
2 4 8
3 4 7
3 5 20
4 5 3

Output:

The given tree does not have all minimal cost edges in any cut.
*/
