'''
2. Consider a graph G and a Minimum Spanning Tree T. These already exist in memory, in
whichever form (adjacency list/array) you like. G now has a new edge e = (u, v) with the
weight w(u, v).
A. Create a method to update the tree T such that it is a Minimum Spanning Tree
for G. Your method should complete in O(n) time. (10 points)
B. Demonstrate the accuracy or correctness of your algorithm. (10 points)
'''

class Graph:
    def __init__(self, vertices):
        self.V = vertices
        self.graph = []

    def addEdge(self, u, v, w):
        self.graph.append((u, v, w))

    def find(self, parent, i):
        if parent[i] == i:
            return i
        return self.find(parent, parent[i])

    def union(self, parent, rank, x, y):
        xroot = self.find(parent, x)
        yroot = self.find(parent, y)

        if rank[xroot] < rank[yroot]:
            parent[xroot] = yroot
        elif rank[xroot] > rank[yroot]:
            parent[yroot] = xroot
        else:
            parent[yroot] = xroot
            rank[xroot] += 1

    def updateMST(self, newEdge):
        parent = []
        rank = []

        for node in range(self.V):
            parent.append(node)
            rank.append(0)

        self.graph.sort(key=lambda x: x[2])
        mst_weight = 0

        for u, v, w in self.graph:
            x = self.find(parent, u)
            y = self.find(parent, v)

            if x != y:
                mst_weight += w
                self.union(parent, rank, x, y)

        max_weight_edge = self.graph[-1]
        if newEdge[2] < max_weight_edge[2]:
            mst_weight -= max_weight_edge[2]
            mst_weight += newEdge[2]

        return mst_weight

# Input edges
edges = []
print("Enter the number of edges:")
n = int(input())
print("Enter the edges (u v w):")
for _ in range(n):
    u, v, w = map(int, input().split())
    edges.append((u, v, w))

# Input new edge
print("Enter the new edge (u v w):")
new_edge = tuple(map(int, input().split()))

# Create graph and update MST
g = Graph(n)
for u, v, w in edges:
    g.addEdge(u, v, w)

updated_weight = g.updateMST(new_edge)
print("Updated MST Weight:", updated_weight)


'''
Enter the number of edges:
5
Enter the edges (u v w):
0 1 3
0 2 1
1 2 2
1 3 5
2 3 4
Enter the new edge (u v w):
3 4 0
Updated MST Weight: 2
'''