'''
3. You are responsible for dispatching ambulances to emergencies. You have k
ambulances in your fleet parked in various places, and you need to transport them to an
emergency as quickly as possible to assist. You have a map of Seattle represented as
the adjacency list for a weighted, directed graph G with |V | vertices and |E| edges,
where edge weights are positive values denoting the journey time from the source to the
destination. (The number of ambulances, k, is much fewer than the number of vertices |V
|.) You also have a list of vertices reflecting the locations of each of your ambulances
and the vertex representing the location of the new emergency. Figure 1 depicts a
sample graph.

Figure 1 shows an example graph with k = 3 (highlighted vertices). L stands for
emergency, while 1, 2, and 3 are ambulances. Other intermediate sites include F, R, and
Q. 1-L, 2-Q-L, and 3-2-Q-L are the shortest paths from 1, 2, and 3 to L, respectively.
suppose you can't change the presented graph and see what we can do.
A. Explain how you would use Dijkstra's algorithm to find the shortest route from
each ambulance to the emergency vertex. (You should output the whole path
rather than simply how long it takes.) (10 points)
B. How long does this procedure take? Provide a simplified, tight big-O in k, |V |,
and/or |E| for the runtime. (10 points)
C. How much more room is required for this process? Provide a simplified, tight
big-O in terms of k, |V |, and/or |E| for memory utilization. Consider the space

necessary for Dijkstra's algorithm's information table (tight-O (|V |)) and the space
required for the output. (10 points)
'''

import heapq

def dijkstra(graph, start):
    distances = {vertex: float('infinity') for vertex in graph}
    distances[start] = 0
    priority_queue = [(0, start)]

    while priority_queue:
        current_distance, current_vertex = heapq.heappop(priority_queue)

        if current_distance > distances[current_vertex]:
            continue

        for neighbor, weight in graph[current_vertex].items():
            distance = current_distance + weight
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                heapq.heappush(priority_queue, (distance, neighbor))

    return distances

# Sample graph
graph = {
    '1': {'2': 1, 'L': 2},
    '2': {'Q': 1},
    '3': {'F': 4, '2': 4},
    'F': {'R': 1, 'L': 10},
    'Q': {'L': 1, '2': 2},
    'L': {'R': 2, '1': 1, 'Q': 1, '3': 2},
    'R': {}
}

# Ambulance locations
ambulance_locations = ['1', '2', '3']

emergency_vertex = 'L'
shortest_distances = {}

for ambulance in ambulance_locations:
    shortest_distances[ambulance] = dijkstra(graph, ambulance)

for ambulance, distances in shortest_distances.items():
    print(f"Shortest path from ambulance {ambulance} to emergency: {distances[emergency_vertex]}")

'''
Let's analyze the runtime complexity:

V: Number of vertices
E: Number of edges
k: Number of ambulances
For each ambulance, Dijkstra's algorithm runs in O((V + E) * log(V)) time 
(using a min-heap implementation). Since there are k ambulances, the overall 
time complexity is O(k * (V + E) * log(V)).
'''
# Part B: Runtime Complexity
print("\nPart B:")
print("Runtime complexity: O(k * (V + E) * log(V))")


'''
Part C: Memory Utilization
Memory required:

Graph representation: O(|V| + |E|)
Dijkstra's algorithm information table: O(|V|)
Shortest path storage for each ambulance: O(k * |V|)
Output memory: O(k)
Overall memory complexity: O(|V| + |E| + k * |V| + k)
'''

# Part C: Memory Utilization
print("\nPart C:")
print("Memory complexity: O(|V| + |E| + k * |V| + k)")